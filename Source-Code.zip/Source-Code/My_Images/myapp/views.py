from django.shortcuts import render, redirect
from django.views import generic
from .models import Detail, Picture

from .forms import (
    DetailModelForm,
    PictureFormset
)


class PictureView(generic.ListView):

    model = Detail
    context_object_name = 'details'
    template_name = 'myapp/view.html'

class HomeView(generic.ListView):

    model = Detail
    context_object_name = 'details'
    template_name = 'myapp/home.html'

def uploads(request):
    template_name = 'myapp/upload.html'
    if request.method == 'GET':
        detailform = DetailModelForm(request.GET or None)
        formset = PictureFormset(queryset=Picture.objects.none())
    elif request.method == 'POST':
        detailform = DetailModelForm(request.POST)
        formset = PictureFormset(request.POST, request.FILES)
        if detailform.is_valid() and formset.is_valid():
            detail = detailform.save()
            for form in formset:
                image = form.save(commit=False)
                image.detail = detail
                image.save()
            return redirect('myapp:picture')
    return render(request, template_name, {
        'detailform': detailform,
        'formset': formset
    })

