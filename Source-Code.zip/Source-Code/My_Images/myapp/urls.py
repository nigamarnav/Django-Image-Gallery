from django.urls import re_path


from .views import (
    uploads,
    PictureView,
    HomeView,
)

app_name = 'myapp'

urlpatterns = [
    re_path(r'^detail/upload', uploads, name='uploads'),
    re_path(r'^detail/view', PictureView.as_view(), name='picture'),
    re_path(r'^detail/home', HomeView.as_view(), name='home')
]