from django.contrib import admin

from .models import Detail, Picture


admin.site.register(Detail)
admin.site.register(Picture)