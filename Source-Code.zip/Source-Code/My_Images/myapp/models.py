from django.db import models


class Detail(models.Model):
    title = models.CharField(max_length = 100)
    description = models.TextField()

    class Meta:
        db_table = 'detail'

    def __str__(self):
        return self.title 

    def get_pictures(self):
    	return self.pictures.all()
    	#return Picture.objects.filter()


class Picture(models.Model):

    picture = models.ImageField(upload_to = 'pictures/')
    detail = models.ForeignKey(Detail, related_name='pictures', on_delete=models.SET_NULL, null=True)

    class Meta:
        db_table = 'picture'

