from django import forms
from django.forms import modelformset_factory

from .models import Detail, Picture

class DetailModelForm(forms.ModelForm):
    class Meta:
        model = Detail
        fields = ('title', 'description')
        labels = {
            'name': 'Title'
        }
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Title here'
                }
            )
        }
        labels = {
            'name': 'Description'
        }
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Description here'
                }
            )
        }
PictureFormset = modelformset_factory(
    Picture,
    fields=('picture', ),
    extra=1,
    widgets={
        'name': forms.FileInput(
            attrs={
                'class': 'form-control',
            }
        )
    }
)